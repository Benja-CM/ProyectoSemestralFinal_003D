from django.shortcuts import render,redirect
from django.contrib import messages
from .models import Raza, Mascota
# Create your views here.
def index(request):
    return render(request,'menu/index.html')

def home(request):
    return render(request,'menu/home.html')

def contacto(request):
    return render(request,'menu/contacto.html')

def borgona(request):
    nombreMascota = "Copito de Nieve"
    edadMascota = 3
    razaMascota= "Pitbull"
    lista =["Marrón","Blanco","Negro"]

    contexto = {
        "nombre":nombreMascota,
        "edad":edadMascota,
        "raza":razaMascota,
        "colores":lista
    }
    return render(request,'menu/borgona.html', contexto)


def listado(request):
    mascotas = Mascota.objects.all()
    contexto = {
        "animales": mascotas
    }
    return render(request,'menu/ListadoM.html',contexto)

def agregar(request):
    razas = Raza.objects.all()
    contexto ={
        "especies": razas
    }
    return render(request,'menu/agregar.html',contexto)

def modificar(request, chip):
    razas = Raza.objects.all()
    mascota = Mascota.objects.get(codigoChip = chip)
    contexto = {
        "datos": mascota,
        "listaRazas": razas
    }
    return render(request,'menu/modificar.html', contexto)

def registrarMascota(request):
    chipM = request.POST['chip']
    nombreM = request.POST['nombre']
    edadM = request.POST['edad']
    razaM = request.POST['raza']
    fotoM = request.FILES['foto']

    registroRaza = Raza.objects.get(codigoRaza = razaM)

    Mascota.objects.create(codigoChip = chipM, nombreMascota = nombreM,
                           edad = edadM, foto = fotoM,
                           raza = registroRaza)
    return redirect('agregar')

def eliminarMascota(request,chip):
    mascota = Mascota.objects.get(codigoChip = chip)
    mascota.delete()
    return redirect('listado') 

def actualizarMascota(request):
    chipM = request.POST['chip']
    nombreM = request.POST['nombre']
    edadM = request.POST['edad']
    razaM = request.POST['raza']

    mascota = Mascota.objects.get(codigoChip = chipM)
    mascota.nombreMascota = nombreM
    mascota.edad = edadM

    registroRaza = Raza.objects.get(codigoRaza = razaM)
    mascota.raza = registroRaza
    mascota.save()
    messages.add_message(request, messages.INFO, 'La mascota fue modificada exitosamente.')
    return redirect('listado')

def mascota_modd(request):
    form = actualizarMascota()

    if request.method == "POST":
        form = actualizarMascota(request.POST, request.FILES)

        if form.is_valid():
            form.save()
            messages.success(request, "La mascota fue modificada exitosamente.")
            return redirect("pos:producto-list")

    return render(request, "core/ListadoM.html", {"form": form})