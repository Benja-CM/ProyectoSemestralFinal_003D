from django.contrib import admin
from .models import Mascota,Raza
# Register your models here.

admin.site.register(Mascota)
admin.site.register(Raza)


