from django.db import models

# Create your models here.
class Raza(models.Model):
    codigoRaza = models.AutoField(primary_key=True,verbose_name='Código de la Raza')
    nombreRaza = models.CharField(max_length=20, blank=True, null=True)
    def __str__(self) -> str:
        return self.nombreRaza

class Mascota(models.Model):
    codigoChip = models.CharField(max_length=20)
    nombreMascota = models.CharField(max_length=30)
    edad = models.IntegerField()
    foto = models.ImageField(upload_to="mascotas")
    raza = models.ForeignKey(Raza,on_delete=models.CASCADE)
    def __str__(self) -> str:
        return self.nombreMascota

