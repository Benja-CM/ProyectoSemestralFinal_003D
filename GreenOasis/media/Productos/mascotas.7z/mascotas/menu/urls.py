from django.contrib import admin
from django.urls import path, include
from .views import registrarMascota,listado,agregar,modificar,index,home,contacto,borgona,eliminarMascota,actualizarMascota

urlpatterns = [
    path('paginahome/',index,name="index"),
    path('',home,name="home"),
    path('contacto/',contacto,name="contacto"),
    path('borgona/',borgona,name="borgona"),
    path('listado/',listado,name="listado"),
    path('agregar/',agregar,name="agregar"),
    path('modificar/<chip>',modificar,name="modificar"),
    path('registrarMascota/',registrarMascota,name="registrarMascota"),
    path('eliminarMascota/<chip>',eliminarMascota,name="eliminarMascota"),
    path('actualizarMascota/',actualizarMascota,name="actualizarMascota"),
]